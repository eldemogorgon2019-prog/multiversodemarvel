# Marvel Tracker

PWA instalable basada en el componente Marvel Tracker proporcionado.

## Publicar en GitHub Pages

1. Crea un repositorio nuevo en GitHub.
2. Sube todo el contenido de esta carpeta.
3. Usa la rama `main`.
4. En Settings → Pages, selecciona GitHub Actions como fuente si GitHub lo solicita.
5. El workflow desplegará la aplicación automáticamente.

En Android/Chrome, abre la URL publicada y usa **Instalar aplicación** cuando aparezca.
