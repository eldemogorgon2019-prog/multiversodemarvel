import { useState, useEffect, useMemo } from 'react';
import { Check, Shield, Zap, Tv, RotateCcw } from 'lucide-react';

const UCM_TITLES = [
  'Capitán América: El primer vengador',
  'Capitana Marvel',
  'Iron Man',
  'Iron Man 2',
  'El increíble Hulk',
  'Thor',
  'Los Vengadores',
  'Thor: El mundo oscuro',
  'Iron Man 3',
  'Capitán América: El soldado de invierno',
  'Guardianes de la Galaxia',
  'Guardianes de la Galaxia Vol. 2',
  'Vengadores: La era de Ultrón',
  'Ant-Man',
  'Capitán América: Civil War',
  'Black Widow',
  'Black Panther',
  'Spider-Man: Homecoming',
  'Doctor Strange',
  'Thor: Ragnarok',
  'Ant-Man y la Avispa',
  'Vengadores: Infinity War',
  'Vengadores: Endgame',
  'Loki',
  'WandaVision',
  'Falcon y el Soldado de Invierno',
  'Shang-Chi y la leyenda de los Diez Anillos',
  'Spider-Man: Lejos de casa',
  'Eternals',
  'Spider-Man: No Way Home',
  'Doctor Strange en el multiverso de la locura',
  'Thor: Love and Thunder',
  'Black Panther: Wakanda Forever',
  'Ant-Man y la Avispa: Quantumanía',
  'Guardianes de la Galaxia Vol. 3',
  'The Marvels',
  'Capitán América: Brave New World',
  'Thunderbolts*',
  'The Fantastic Four: First Steps',
  'Spider-Man: Brand New Day',
];

const MUTANT_TITLES = [
  'X-Men',
  'X-Men 2',
  'X-Men: La decisión final',
  'X-Men orígenes: Lobezno',
  'X-Men: Primera generación',
  'Lobezno inmortal',
  'X-Men: Días del futuro pasado',
  'Deadpool',
  'X-Men: Apocalipsis',
  'Logan',
  'Deadpool 2',
  'X-Men: Fénix Oscura',
  'Los nuevos mutantes',
  'Deadpool y Lobezno',
];

const SERIES = new Set(['Loki', 'WandaVision', 'Falcon y el Soldado de Invierno']);

function buildList(titles, prefix) {
  return titles.map((title, i) => ({
    id: `${prefix}-${i + 1}`,
    order: i + 1,
    title,
    isSeries: SERIES.has(title),
  }));
}

const UCM = buildList(UCM_TITLES, 'ucm');
const MUTANTS = buildList(MUTANT_TITLES, 'mut');
const TOTAL = UCM.length + MUTANTS.length;

const COLORS = {
  ink: '#0B0B0E',
  inkRaised: '#161519',
  line: '#28262C',
  paper: '#F3EEE3',
  text: '#EDEAE3',
  muted: '#9A97A0',
  red: '#E4232C',
  blue: '#2A5FE0',
  gold: '#E8B23D',
};

const THEMES = {
  ucm: { key: 'ucm', label: 'UCM / MVSO', accent: COLORS.red, icon: Shield, list: UCM },
  mutantes: { key: 'mutantes', label: 'Mutantes', accent: COLORS.blue, icon: Zap, list: MUTANTS },
};

const STORAGE_KEY = 'marvel-tracker-watched-v1';

const FONT_STYLES = `
  @import url('https://fonts.googleapis.com/css2?family=Anton&family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;600;700&display=swap');
  .mv-display { font-family: 'Anton', 'Arial Narrow', sans-serif; }
  .mv-mono { font-family: 'JetBrains Mono', ui-monospace, monospace; }
  .mv-body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; }
  @media (prefers-reduced-motion: reduce) {
    .mv-root * { transition: none !important; animation: none !important; }
  }
`;

function hexToRgba(hex, alpha) {
  const h = hex.replace('#', '');
  const r = parseInt(h.substring(0, 2), 16);
  const g = parseInt(h.substring(2, 4), 16);
  const b = parseInt(h.substring(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export default function MarvelTracker() {
  const [watched, setWatched] = useState({});
  const [ready, setReady] = useState(false);
  const [tabKey, setTabKey] = useState('ucm');
  const [filter, setFilter] = useState('all');
  const [confirmReset, setConfirmReset] = useState(false);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const value = window.localStorage.getItem(STORAGE_KEY);
        if (mounted && value) setWatched(JSON.parse(value));
      } catch (e) {
        // todavía no hay progreso guardado
      } finally {
        if (mounted) setReady(true);
      }
    })();
    return () => { mounted = false; };
  }, []);

  async function persist(next) {
    setWatched(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch (e) {
      console.error('No se pudo guardar el progreso', e);
    }
  }

  function toggle(id) {
    persist({ ...watched, [id]: !watched[id] });
  }

  async function resetAll() {
    await persist({});
    setConfirmReset(false);
  }

  const ucmSeen = useMemo(() => UCM.filter((t) => watched[t.id]).length, [watched]);
  const mutSeen = useMemo(() => MUTANTS.filter((t) => watched[t.id]).length, [watched]);
  const totalSeen = ucmSeen + mutSeen;

  const theme = THEMES[tabKey];
  const filtered = theme.list.filter((t) => {
    if (filter === 'watched') return !!watched[t.id];
    if (filter === 'pending') return !watched[t.id];
    return true;
  });

  if (!ready) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: COLORS.ink }}>
        <div className="mv-mono text-xs tracking-widest" style={{ color: COLORS.muted }}>CARGANDO…</div>
      </div>
    );
  }

  return (
    <div
      className="mv-root mv-body min-h-screen pb-16"
      style={{
        background: `radial-gradient(ellipse 900px 500px at 50% -10%, #1b1a20 0%, ${COLORS.ink} 60%)`,
        color: COLORS.text,
      }}
    >
      <style>{FONT_STYLES}</style>

      {/* Cabecera */}
      <div className="px-5 pt-9 pb-5">
        <div className="mv-mono" style={{ color: COLORS.gold, fontSize: '11px', letterSpacing: '0.2em' }}>
          SEGUIMIENTO DE VISIONADO
        </div>
        <h1 className="mv-display text-4xl mt-1 tracking-tight" style={{ color: COLORS.paper }}>MARVEL</h1>

        <div className="flex w-full mt-4 rounded-full overflow-hidden" style={{ height: '3px' }}>
          <div className="h-full" style={{ width: '50%', background: COLORS.red }} />
          <div className="h-full" style={{ width: '50%', background: COLORS.blue }} />
        </div>

        <div className="flex items-end justify-between mt-4">
          <div className="mv-mono text-3xl font-semibold" style={{ color: COLORS.paper }}>
            {totalSeen}<span style={{ color: COLORS.muted }}>/{TOTAL}</span>
          </div>
          <div className="mv-mono text-xs" style={{ color: COLORS.muted }}>
            {Math.round((totalSeen / TOTAL) * 100)}% completado
          </div>
        </div>

        <div
          className="relative h-2 rounded-full overflow-hidden flex mt-2"
          style={{ background: COLORS.inkRaised, border: `1px solid ${COLORS.line}` }}
        >
          <div style={{ width: `${(ucmSeen / TOTAL) * 100}%`, background: COLORS.red, transition: 'width 400ms ease' }} />
          <div style={{ width: `${(mutSeen / TOTAL) * 100}%`, background: COLORS.blue, transition: 'width 400ms ease' }} />
        </div>
      </div>

      {/* Pestañas */}
      <div role="tablist" className="px-5 flex gap-2">
        {Object.values(THEMES).map((t) => {
          const Icon = t.icon;
          const active = t.key === tabKey;
          const seen = t.key === 'ucm' ? ucmSeen : mutSeen;
          return (
            <button
              key={t.key}
              role="tab"
              aria-selected={active}
              onClick={() => setTabKey(t.key)}
              className="flex-1 rounded-t-lg px-3 py-3 text-left transition-colors"
              style={{
                background: active ? hexToRgba(t.accent, 0.14) : COLORS.inkRaised,
                borderBottom: `3px solid ${active ? t.accent : COLORS.line}`,
              }}
            >
              <div className="flex items-center gap-1.5">
                <Icon size={14} style={{ color: active ? t.accent : COLORS.muted }} />
                <span className="mv-display text-sm tracking-wide" style={{ color: active ? COLORS.paper : COLORS.muted }}>
                  {t.label.toUpperCase()}
                </span>
              </div>
              <div className="mv-mono text-xs mt-1" style={{ color: active ? t.accent : COLORS.muted }}>
                {seen}/{t.list.length}
              </div>
            </button>
          );
        })}
      </div>

      {/* Filtros */}
      <div className="px-5 pt-4 flex items-center gap-4">
        {[
          { key: 'all', label: 'Todas' },
          { key: 'pending', label: 'Pendientes' },
          { key: 'watched', label: 'Vistas' },
        ].map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className="mv-mono text-xs pb-1 tracking-wide transition-colors"
            style={{
              color: filter === f.key ? COLORS.paper : COLORS.muted,
              borderBottom: filter === f.key ? `2px solid ${theme.accent}` : '2px solid transparent',
            }}
          >
            {f.label.toUpperCase()}
          </button>
        ))}
      </div>

      {/* Lista */}
      <div className="px-5 pt-4 space-y-2">
        {filtered.length === 0 && (
          <div className="mv-mono text-center text-xs py-12 tracking-wide" style={{ color: COLORS.muted }}>
            NADA POR AQUÍ
          </div>
        )}
        {filtered.map((item) => {
          const isWatched = !!watched[item.id];
          return (
            <button
              key={item.id}
              aria-pressed={isWatched}
              onClick={() => toggle(item.id)}
              className="w-full flex items-center gap-3 p-3 rounded-lg text-left transition-all active:scale-95"
              style={{
                background: COLORS.inkRaised,
                border: `1px solid ${COLORS.line}`,
                opacity: isWatched ? 0.55 : 1,
              }}
            >
              <div
                className="shrink-0 w-8 h-8 rounded-md flex items-center justify-center mv-mono text-xs font-semibold transition-transform"
                style={
                  isWatched
                    ? { background: COLORS.paper, border: `2px solid ${theme.accent}`, transform: 'rotate(-7deg)' }
                    : { background: hexToRgba(theme.accent, 0.15), color: theme.accent, border: `1px solid ${hexToRgba(theme.accent, 0.3)}` }
                }
              >
                {isWatched ? <Check size={14} style={{ color: theme.accent }} /> : item.order}
              </div>
              <div className="flex-1 min-w-0">
                <div
                  className="text-sm leading-snug"
                  style={{ color: isWatched ? COLORS.muted : COLORS.text, textDecoration: isWatched ? 'line-through' : 'none' }}
                >
                  {item.title}
                </div>
                {item.isSeries && (
                  <div className="mv-mono flex items-center gap-1 mt-1 tracking-wide" style={{ color: COLORS.muted, fontSize: '10px' }}>
                    <Tv size={10} /> SERIE
                  </div>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {/* Reiniciar */}
      <div className="px-5 pt-8">
        {!confirmReset ? (
          <button
            onClick={() => setConfirmReset(true)}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-lg mv-mono text-xs tracking-wide transition-colors"
            style={{ color: COLORS.muted, border: `1px solid ${COLORS.line}` }}
          >
            <RotateCcw size={12} /> REINICIAR PROGRESO
          </button>
        ) : (
          <div className="flex gap-2">
            <button
              onClick={resetAll}
              className="flex-1 py-3 rounded-lg mv-mono text-xs tracking-wide font-semibold"
              style={{ color: COLORS.red, background: hexToRgba(COLORS.red, 0.12), border: `1px solid ${hexToRgba(COLORS.red, 0.35)}` }}
            >
              CONFIRMAR
            </button>
            <button
              onClick={() => setConfirmReset(false)}
              className="flex-1 py-3 rounded-lg mv-mono text-xs tracking-wide"
              style={{ color: COLORS.muted, border: `1px solid ${COLORS.line}` }}
            >
              CANCELAR
            </button>
          </div>
        )}
      </div>

      <div className="px-5 pt-6 text-center mv-mono tracking-wide" style={{ color: COLORS.muted, fontSize: '10px' }}>
        TOCA UN TÍTULO PARA MARCARLO COMO VISTO
      </div>
    </div>
  );
}
