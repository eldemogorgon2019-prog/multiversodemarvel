import React from 'react';
import { createRoot } from 'react-dom/client';
import MarvelTracker from './marvel-tracker.jsx';

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <MarvelTracker />
  </React.StrictMode>
);

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js').catch(console.error);
  });
}
